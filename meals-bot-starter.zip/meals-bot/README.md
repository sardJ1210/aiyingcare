# meals-bot 快速开始

## 需要做的
1. 在飞书多维表格建表（字段：用餐日期/姓名/餐别(多选)/成人份数/儿童份数(可不填)）。
2. 复制表单链接；记下 `app_token` 和 `table_id`。
3. 在企业微信目标群添加“群机器人”，复制 Webhook URL。
4. 本仓库里：
   - `meals_bot.py`：机器人脚本（提醒链接会自动加 `prefill_用餐日期=今天`）。
   - `.github/workflows/meals.yml`：四个定时任务（UTC）。

## 在仓库 Secrets 里填
- `FEISHU_APP_ID`、`FEISHU_APP_SECRET`
- `BITABLE_APP_TOKEN`、`BITABLE_TABLE_ID`
- `WECHAT_WEBHOOK`
- `FORM_URL`（飞书表单链接）
- （可选）`MENTION_MOBILES`（被 @ 的手机号，逗号分隔）
- （可选）`LOCK_DATE` = `1`（提醒里锁定“用餐日期”不可改）
